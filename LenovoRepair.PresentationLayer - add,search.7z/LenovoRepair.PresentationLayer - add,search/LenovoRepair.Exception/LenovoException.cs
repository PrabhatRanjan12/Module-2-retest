﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LenovoRepair.Exceptions
{
    public class LenovoException:ApplicationException
    {
        public LenovoException() : base()
        {


        }

        public LenovoException(string message) : base(message)
        {


        }
        public LenovoException(string message, Exception innerException) : base(message, innerException)
        {
        }
    }
}
