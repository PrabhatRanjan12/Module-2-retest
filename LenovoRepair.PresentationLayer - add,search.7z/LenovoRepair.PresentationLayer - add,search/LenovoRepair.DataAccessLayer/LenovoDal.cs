﻿using LenovoRepair.Entities;
using LenovoRepair.Exceptions;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LenovoRepair.DataAccessLayer
{
    public class LenovoDal
    {
        static string conStr = string.Empty;
        SqlConnection con = null;
        SqlCommand cmd = null;
        static LenovoDal()
        {
            conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;

        }

        public LenovoDal()
        {
            con = new SqlConnection(conStr);

        }

        public int AddDetails(LenovoEntities prod)
        {
            int add = 0;
            try
            {
                cmd = new SqlCommand();
                cmd.CommandText = "Prabhat_Ranjan.AddProduct";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@ServiceId", prod.ServiceID);
                cmd.Parameters.AddWithValue("@DateNow", prod.Date);
                cmd.Parameters.AddWithValue("@OwnerName", prod.CustomerName);
                cmd.Parameters.AddWithValue("@ContactNumber", prod.ContactNumber);
                cmd.Parameters.AddWithValue("@DeviceType", prod.DeviceType);
                cmd.Parameters.AddWithValue("@ProductId", prod.ProductId);
                cmd.Parameters.AddWithValue("@IssueDescription", prod.IssueDescription);
                con.Open();
                add = cmd.ExecuteNonQuery();


            }
            catch (LenovoException)
            {

                throw;
            }
            catch (SystemException )
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return add;

        }
        public DataTable Display()
        {
            DataTable dt = null;
            try
            {

                cmd = new SqlCommand();
                cmd.CommandText = "Prabhat_Ranjan.DisplayProduct";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;

                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dt = new DataTable();
                    dt.Load(dr);
                }
            }
            catch (LenovoException) { throw; }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return dt;


        }
        public DataTable Search(string productId)
        {
            DataTable dt = null;
            try
            {
                //  con = new SqlConnection();
                //con.ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
                cmd = new SqlCommand();
                cmd.CommandText = "Prabhat_Ranjan.uspSearchProduct";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ServiceID",productId);

                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    
                    //dr.Read();
                    dt = new DataTable();
                    dt.Load(dr);
                    //dr.Read();
                    //p = new LenovoEntities
                    //{
                    //    //ServiceID = dr["ServiceID"].ToString(),
                    //    CustomerName = dr["OwnerName"].ToString(),
                    //    ContactNumber = long.Parse(dr["ContactNumber"].ToString()),
                    //    DeviceType = dr["DeviceType"].ToString(),
                    //    ProductId = int.Parse(dr["ProductId"].ToString()),
                    //    IssueDescription = dr["IssueDescription"].ToString(),
                    //    Date=DateTime.Parse(dr["DateNow"].ToString())
                    //};
                    //dr.Close();
                }
            }
            catch (LenovoException) { throw; }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return dt;
        }
    }
}
