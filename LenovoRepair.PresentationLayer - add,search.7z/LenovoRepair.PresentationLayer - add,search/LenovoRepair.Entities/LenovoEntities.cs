﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LenovoRepair.Entities
{
    public class LenovoEntities
    {
        public string ServiceID { get; set; }
        public string CustomerName { get; set; }
        public long ContactNumber { get; set; }
        public string DeviceType { get; set; }
        public Int32 ProductId { get; set; }
        public string IssueDescription { get; set; }
        public DateTime Date { get; set; }
    }
}
